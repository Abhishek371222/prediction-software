"""Generate a styled Excel changelog (CHANGELOG.xlsx) for the
Atomik Simulation Engine, mirroring CHANGELOG.md."""

import os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# --- Atomik palette --------------------------------------------------------
BG      = "0D0D12"   # near-black background
PANEL   = "17171D"   # panel
ACCENT  = "44D9E6"   # cyan
HEAD    = "F5F7FA"   # near-white
LABEL   = "B8C0CC"   # soft gray
SUCCESS = "53D769"
WARNING = "FF6B6B"
ZEBRA   = "1E1E26"   # alternate row

thin = Side(style="thin", color="2C2F38")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)


def title_font(size=18, color=HEAD):
    return Font(name="Calibri", size=size, bold=True, color=color)


def head_font():
    return Font(name="Calibri", size=11, bold=True, color=BG)


def body_font(color=HEAD, bold=False):
    return Font(name="Calibri", size=10, color=color, bold=bold)


def style_header_row(ws, row, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = PatternFill("solid", fgColor=ACCENT)
        cell.font = head_font()
        cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        cell.border = BORDER
    ws.row_dimensions[row].height = 22


def write_table(ws, start_row, headers, rows, widths, type_colors=None,
                type_col=None):
    # header
    for i, h in enumerate(headers, start=1):
        ws.cell(row=start_row, column=i, value=h)
    style_header_row(ws, start_row, len(headers))

    # body
    r = start_row + 1
    for ridx, row in enumerate(rows):
        for i, val in enumerate(row, start=1):
            cell = ws.cell(row=r, column=i, value=val)
            cell.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
            cell.border = BORDER
            base = ZEBRA if ridx % 2 else PANEL
            cell.fill = PatternFill("solid", fgColor=base)
            cell.font = body_font(LABEL if i != 1 else HEAD)
        # colour the Type column if requested
        if type_colors and type_col:
            t = row[type_col - 1]
            col = type_colors.get(t)
            if col:
                tc = ws.cell(row=r, column=type_col)
                tc.font = body_font(col, bold=True)
        r += 1

    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    return r


def banner(ws, text, sub, ncols):
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    c = ws.cell(row=1, column=1, value=text)
    c.font = title_font(18, HEAD)
    c.fill = PatternFill("solid", fgColor=BG)
    c.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[1].height = 34

    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
    s = ws.cell(row=2, column=1, value=sub)
    s.font = Font(name="Calibri", size=10, italic=True, color=ACCENT)
    s.fill = PatternFill("solid", fgColor=BG)
    s.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[2].height = 18


def paint_bg(ws, nrows, ncols):
    for r in range(1, nrows + 1):
        for c in range(1, ncols + 1):
            cell = ws.cell(row=r, column=c)
            if cell.fill.fgColor.rgb in (None, "00000000"):
                cell.fill = PatternFill("solid", fgColor=BG)


wb = Workbook()

# ===========================================================================
# Sheet 1: Overview
# ===========================================================================
ws = wb.active
ws.title = "Overview"
ws.sheet_view.showGridLines = False
banner(ws, "Atomik Simulation Engine - Changelog",
       "Generated from CHANGELOG.md  |  follows Keep a Changelog + SemVer", 4)

rows = [
    ["1.4.0.5", "2026-09-25", "BEM 2inch as a second speaker model",
     "2\" BEM HF horn added alongside Q21S with per-unit model tags, so one scene can "
     "mix both and each unit is simulated from its own model's measured data; own 9-band "
     "frequency catalogue (64 - 17266 Hz), own embedded polar pack; unit names now use a "
     "space-free model tag numbered within their own model (BEM2inch_1); redundant "
     "Measurement set row removed"],
    ["1.4.0.4", "2026-09-21", "New Rel. SPL gradient + readable legend",
     "Six-stop Figma gradient (#FF0103 -> #F65556 -> #CD617C -> #3281B9 -> #003A6C -> "
     "#151515) with the designer's uneven stop positions, giving a longer hot band; "
     "legend tick labels 18% larger"],
    ["1.4.0.2", "2026-09-19", "8-unit cap + parallel solve + autosave fixes",
     "Q21S units capped at 8; SPL solve across all cores (0.4s -> 0.1s at 8 units); "
     "autosave timing and status corrected; Opacity readout, sizing and greying; grey "
     "sidebar outlines, larger field labels, bigger Recent Projects list"],
    ["1.4.0.1", "2026-09-18", "No letterboxing + pan + true Q21S size",
     "Fill-the-canvas fit is the zoom floor, so the plot never letterboxes; pan fixed "
     "and middle-drag pans from any tool; Q21S cabinet corrected to 1546 x 679 x 1024 mm "
     "and drawn to scale; SPL caption back at the canvas edge; lighter grid lines"],
    ["1.4.0", "2026-09-18", "Figma UI cut + square full-bleed grid",
     "New ATOMIK. wordmark, ribbon, sidebar and dashboard built to measured Figma geometry; "
     "Heatmap renamed Gradient Plot; square grid cells ruled edge to edge; contrast-aware axis "
     "numbers and caption; sidebar holds its width share at any aspect; 4K scale ceiling; "
     "icon-free info panels with a close cross; v1.4.0 Windows Release"],
    ["1.3.9", "2026-09-15", "15W750 second measurement source",
     "15W750 added alongside Q21S as a fully isolated source; per-model frequency isolation so "
     "browsing one model never affects the active simulation"],
    ["1.3.8", "2026-09-04", "Command line + aliases",
     "Command registry (short=full); typed-point DRAW; MOVE/ZOOM sessions; "
     "dock/undock terminal; Atomik HELP; Esc keeps float focused; v1.3.8 Windows Release"],
    ["1.3.7", "2026-09-02", "Gain fix + text box + drawing UX",
     "Gain slider affects SPL again; sidebar Delete removes all selected speakers; "
     "text box annotations (fill + rotate); clean slate on first open; Range off by default; "
     "Esc/Line/Shape-menu fixes; command terminal; delay max 10 ms; v1.3.7 Windows Release"],
    ["1.3.6", "2026-08-31", "Mic snap + shape-edge tak",
     "Restored original mic Drag::Mic ring snap; tak when drawings meet edge-to-edge; "
     "start.md for build/run; v1.3.6 Windows Release"],
    ["1.3.5", "2026-08-26", "Mic tool + embedded Q21S Setup",
     "Virtual mics, FR floating window, Show Degrees, tak snap sound; "
     "Q21S CSVs baked into EXE; Windows Setup without Excel/Data folder"],
    ["1.3.0", "2026-08-21", "Q21S BEM heatmap + Windows/mac product",
     "BEM polar×1/r full-grid SPL, cardioid, Q21S 750×784×917 mm, plot tools/shapes, "
     "undo/redo, ATOMIK branding, version archive, Windows portable ZIP (EXE+Data)"],
    ["1.2.x", "~2026-07", "Beta UI redesign (betav1.2.3)",
     "Graph colors.pdf chrome: brand tokens, heatmap colour stops, light/dark sidebar; "
     "packaged as betav1.2.3-style Release"],
    ["1.1.0", "2026-06-29", "Major feature + UX release",
     "Theming, project dashboard/.atmk, heatmap + PDF export, grid/CAD-DXF, "
     "array presets, dual datasets, responsive window, branded installer"],
    ["1.0.0", "2026-06-22", "Initial baseline",
     "Dual-subwoofer (XN18) prediction & visualisation in a 30x30 m world; "
     "measured directivity added 2026-06-24"],
]
write_table(ws, 4, ["Version", "Date", "Summary", "Highlights"],
            rows, [12, 14, 26, 80])
ws.freeze_panes = "A5"

# ===========================================================================
# Sheet 2: v1.4.0.5 detailed changes
# ===========================================================================
ws1405 = wb.create_sheet("v1.4.0.5 Changes")
ws1405.sheet_view.showGridLines = False
banner(ws1405, "v1.4.0.5  -  Detailed Changes",
       "2026-09-25  |  BEM 2inch as a second speaker model", 5)

A, C, F = "Added", "Changed", "Fixed"
v1405 = [
    ["Models", A, "BEM 2inch as a second speaker model",
     "Speaker model picker in sidebar section 2 chooses what new units are created "
     "as; every unit carries its own model tag, so a scene can mix Q21S and "
     "BEM 2inch and each is simulated from its own measured data - never blended",
     "2026-09-25"],
    ["Models", A, "Own frequency catalogue",
     "9 native BEM bands 64, 135, 243, 507, 1057, 1904, 3971, 8280, 17266 Hz; Q21S "
     "keeps its own 20 - 401 Hz list. Switching models rebuilds the Frequency "
     "dropdown from scratch and each model remembers its last band", "2026-09-25"],
    ["Data", A, "Own embedded measured pack",
     "BEM2inch_<Hz>Hz_<dist>m.csv polars at 0.5/1.0/2.0 m plus BEM2inch_Field_<Hz>Hz"
     ".q21f absolute fields, baked in as EmbeddedBEM2inchData so the EXE still runs "
     "with no sidecar Data/ folder", "2026-09-25"],
    ["Data", A, "2-inch BEM exporter",
     "docs/bem2inch_plots/export_2inch_native_hz_pack.py. Handles this set's "
     "6-column layout and its half-plane domain (z = 0..+10 m, source at the edge): "
     "the rear hemisphere is synthesised by tapering from the measured grazing level "
     "to min(grazing, on-axis - 25 dB) instead of extrapolating", "2026-09-25"],
    ["Naming", C, "Unit names use a model tag, numbered per model",
     "A BEM unit placed second overall but first of its model reads BEM2inch_1, not "
     "BEM 2inch_2. Applied to plot label, sidebar list, properties dialog, Info "
     "panel, mic reference picker and PDF report so one unit reads the same "
     "everywhere; headings keep the spaced display name", "2026-09-25"],
    ["Sidebar", C, "Measurement set row removed",
     "Redundant with the Speaker model picker, which is now the single control for "
     "which device is in use", "2026-09-25"],
    ["Packaging", C, "Version -> v1.4.0.5",
     "App, resource, installer, archive HTML/json, Windows Release EXE", "2026-09-25"],
]
write_table(ws1405, 4,
            ["Area", "Type", "Item", "Detail", "When"],
            v1405, [14, 10, 28, 72, 12],
            type_colors={A: SUCCESS, C: ACCENT, F: WARNING}, type_col=2)
ws1405.freeze_panes = "A5"

# ===========================================================================
# Sheet 3: v1.4.0.4 detailed changes
# ===========================================================================
ws1404 = wb.create_sheet("v1.4.0.4 Changes")
ws1404.sheet_view.showGridLines = False
banner(ws1404, "v1.4.0.4  -  Detailed Changes",
       "2026-09-21  |  New Rel. SPL gradient + readable legend", 5)

A, C, F = "Added", "Changed", "Fixed"
v1404 = [
    ["Legend", C, "New Rel. SPL gradient",
     "#FF0103 -> #F65556 -> #CD617C -> #3281B9 -> #003A6C -> #151515, replacing the "
     "seven-stop ramp. Stops are deliberately uneven (red to 30%, crossover at 47%), "
     "which is what lengthens the hot band", "2026-09-21"],
    ["Legend", C, "Tick labels 18% larger",
     "legendTickOnScreen 14.0 -> 16.5", "2026-09-21"],
    ["Packaging", C, "Version -> v1.4.0.4",
     "App, resource, installer, archive HTML/json, Windows Release EXE", "2026-09-21"],
]
write_table(ws1404, 4,
            ["Area", "Type", "Item", "Detail", "When"],
            v1404, [14, 10, 28, 72, 12],
            type_colors={A: SUCCESS, C: ACCENT, F: WARNING}, type_col=2)
ws1404.freeze_panes = "A5"

# ===========================================================================
# Sheet 4: v1.4.0.2 detailed changes
# ===========================================================================
ws1402 = wb.create_sheet("v1.4.0.2 Changes")
ws1402.sheet_view.showGridLines = False
banner(ws1402, "v1.4.0.2  -  Detailed Changes",
       "2026-09-19  |  8-unit cap + parallel solve + autosave fixes", 5)

A, C, F = "Added", "Changed", "Fixed"
v1402 = [
    ["Speakers", A, "Q21S units capped at 8",
     "Enforced in ControlPanel::addSpeakerAt, which + Add, click-to-place and the "
     "terminal SPK all funnel through; each path reports the limit", "2026-09-19"],
    ["Engine", C, "SPL solve runs on all cores",
     "0.4s -> 0.1s for 8 units at 400 Hz / res 400. Rows split across workers; the "
     "four running maxima merge at the end and the per-cell scratch is per-worker "
     "(it was shared - a data race)", "2026-09-19"],
    ["Ribbon", F, "Opacity percentage never changed",
     "MainComponent assigned over fillAlpha_.onValueChange, discarding the bar's "
     "readout sync. The bar owns the callback now and exposes onFillAlphaChanged",
     "2026-09-19"],
    ["Ribbon", C, "Opacity larger, slot widened, greyed when unusable",
     "Caption and value sized from measured glyphs in a 60-unit wider slot; disabled "
     "unless a filled shape is selected or a filling tool is armed", "2026-09-19"],
    ["Autosave", F, "Slow enough to look broken",
     "15 s tick vs a 30 s throttle meant up to 45 s unsaved; now a 2 s tick with a "
     "2 s floor", "2026-09-19"],
    ["Autosave", F, "Edits never showed as unsaved",
     "applyResult reported a blanket Ready after every recompute, overwriting the "
     "dirty state set milliseconds earlier", "2026-09-19"],
    ["Autosave", F, "Fresh project claimed unsaved changes",
     "Construction runs the same change hooks an edit does; the flag is cleared once "
     "at the end of construction", "2026-09-19"],
    ["Sidebar", C, "Grey control outlines, larger field labels",
     "controlBorder #0C0C0C -> #AFAFAF; sidebarFieldLabel 14.3 -> 15.1; Measurement "
     "set hidden (one choice ships)", "2026-09-19"],
    ["Sidebar", C, "Section titles sentence case",
     "1. Frequency (Hz) / 3. Selected Q21S / 4. Simulation; Q21S keeps its capitals "
     "as the product name", "2026-09-21"],
    ["Legend", C, "Rel. SPL tick labels larger",
     "legendTickOnScreen 11.0 -> 14.0; the dB labels were too small to read",
     "2026-09-21"],
    ["Dashboard", C, "Recent Projects bigger",
     "Full button-row width, taller, larger text in both the control and its list "
     "(own LookAndFeel - the two read different hooks)", "2026-09-19"],
    ["Packaging", C, "Version -> v1.4.0.2",
     "App, resource, installer, archive HTML/json, Windows Release EXE", "2026-09-19"],
]
write_table(ws1402, 4,
            ["Area", "Type", "Item", "Detail", "When"],
            v1402, [14, 10, 28, 72, 12],
            type_colors={A: SUCCESS, C: ACCENT, F: WARNING}, type_col=2)
ws1402.freeze_panes = "A5"

# ===========================================================================
# Sheet 3: v1.4.0.1 detailed changes
# ===========================================================================
ws1401 = wb.create_sheet("v1.4.0.1 Changes")
ws1401.sheet_view.showGridLines = False
banner(ws1401, "v1.4.0.1  -  Detailed Changes",
       "2026-09-18  |  No letterboxing + pan + true Q21S size", 5)

A, C, F = "Added", "Changed", "Fixed"
v1401 = [
    ["Plot", A, "Middle-drag pans from any tool",
     "No need to leave the tool you are drawing with", "2026-09-18"],
    ["Plot", C, "Never letterboxes",
     "The fill-the-canvas fit is the zoom floor, so no pale margins at any zoom. Field "
     "stays 100 x 100 m with square cells; the cropped band is reached by panning",
     "2026-09-18"],
    ["Speakers", C, "Q21S dimensions corrected",
     "1546 x 679 x 1024 mm (60.86 x 26.73 x 40.31 in) replaces an incorrect "
     "750 x 784 x 917 mm set; footprint drawn at the field's px/m and the 1/r floor "
     "follows the true depth", "2026-09-18"],
    ["Plot", C, "SPL caption back at the canvas edge",
     "Was inset to the field's left edge, left over from a letterboxed view",
     "2026-09-18"],
    ["Plot", C, "Grid lines lighter over the field",
     "The light theme's opaque plotGrid overpowered the near-black field: major lines "
     "100% -> 42% alpha, minor 45% -> 16%. Weights and thicknesses collected in "
     "UiConfig::PlotGrid", "2026-09-18"],
    ["Plot", F, "Pan did nothing",
     "The view offset was clamped back to zero on every drag. Panning now moves the "
     "view across the field with no re-solve, so it is instant and placement is exact",
     "2026-09-18"],
    ["Plot", F, "Zoom anchored on the field corner",
     "Zooming in walked off into empty space; it now holds the view centre",
     "2026-09-18"],
    ["Packaging", C, "Version -> v1.4.0.1",
     "App, resource, installer, archive HTML/json, Windows Release EXE", "2026-09-18"],
]
write_table(ws1401, 4,
            ["Area", "Type", "Item", "Detail", "When"],
            v1401, [14, 10, 28, 72, 12],
            type_colors={A: SUCCESS, C: ACCENT, F: WARNING}, type_col=2)
ws1401.freeze_panes = "A5"

# ===========================================================================
# Sheet 3: v1.4.0 detailed changes
# ===========================================================================
ws140 = wb.create_sheet("v1.4.0 Changes")
ws140.sheet_view.showGridLines = False
banner(ws140, "v1.4.0  -  Detailed Changes",
       "2026-09-18  |  Figma UI cut + square full-bleed grid", 5)

A, C, F = "Added", "Changed", "Fixed"
v140 = [
    ["Branding", A, "ATOMIK. wordmark",
     "New horizontal logo (with trailing dot) at Figma size/position; light and dark ink "
     "variants generated from the source art", "2026-09-18"],
    ["Ribbon", A, "Snap / Ortho slot",
     "Laid out after Help, captioned and divided like every other cluster, behind "
     "kShowOptionsCluster (off). Ctrl+F and the SNAP / ORTHO verbs stay live", "2026-09-18"],
    ["Help", A, "Info panel",
     "Replaces the stock message box for the info and ? popups: no icon disc, no OK "
     "button, red close cross top-right", "2026-09-18"],
    ["Naming", C, "Heatmap -> Gradient Plot",
     "Canvas caption, stats chip, terminal VIEWSPL, PDF report title and rows, tooltips",
     "2026-09-18"],
    ["Plot", C, "Simulated region follows the view",
     "The fixed 100 x 100 m world is gone: the plot asks for a region shaped to its "
     "own aspect, so the field covers the canvas exactly with square cells, and zoom "
     "changes how many metres are solved rather than cropping a box (2 m - 20 km)",
     "2026-09-18"],
    ["Speakers", F, "X / Y sliders capped at 100 m",
     "Spans were hard-coded 0..100 m and silently clamped every unit to the old box; "
     "they now follow the simulated region", "2026-09-18"],
    ["Speakers", F, "Q21S dimensions corrected",
     "1546 x 679 x 1024 mm (60.86 x 26.73 x 40.31 in) replaces an incorrect "
     "750 x 784 x 917 mm set; footprint drawn at the field's px/m, so the marker is "
     "to scale and the 1/r floor follows the true depth", "2026-09-18"],
    ["Plot", C, "Contrast-aware axis numbers",
     "White with a halo over a rendered field, theme ink over the bare grid; colliding "
     "tick labels are skipped", "2026-09-18"],
    ["Plot", C, "Canvas caption ink",
     "Brand red on the empty grid, white once a device is placed", "2026-09-18"],
    ["Layout", C, "Sidebar tracks window width",
     "Holds the design's 17.7% share at any aspect (was 13.3% at 21:9, 12.4% at 4K)",
     "2026-09-18"],
    ["Layout", C, "Scale ceiling 1.85 -> 2.70",
     "A 4K client area needs 2.63 and was clamped, rendering every band ~30% thinner "
     "than its share of the screen", "2026-09-18"],
    ["Layout", C, "Vertical centring",
     "Run info, export buttons and the status pill centred in their rows", "2026-09-18"],
    ["Theme", C, "Dark theme hidden",
     "Light theme only for this release; code intact", "2026-09-18"],
    ["Plot", F, "Pan did nothing",
     "The solved region fills the view, so clampViewToField pinned the offset back to "
     "zero every drag. Panning now moves the region itself; middle-drag pans from any "
     "tool", "2026-09-18"],
    ["Plot", F, "Zoom anchored on the region corner",
     "Zooming in walked off into empty space; it now keeps the view centre", "2026-09-18"],
    ["Plot", F, "SPL caption sat mid-canvas",
     "Was inset to the field's left edge, left over from the letterboxed view",
     "2026-09-18"],
    ["Measurements", F, "Prediction fell back to omni off-machine",
     "A stored measurementSource of 1 selected a non-existent combo id (blank control) "
     "and pointed at a sidecar shyamGuildMeasurements folder shipped builds lack, so "
     "the engine lost Q21S directivity. Source is validated; combo never blanks",
     "2026-09-18"],
    ["Plot", F, "Speaker markers elongated",
     "Cabinet footprint inherited the view's anisotropy (3.33:1 vs a true 1.22:1 plan "
     "ratio); the glyph is now sized from a single px/m", "2026-09-18"],
    ["Help", F, "Icons shrank on units / theme switch",
     "Header restyle stamped its own inset onto the ribbon's adopted glyphs, and JUCE "
     "skips resized() when bounds do not change", "2026-09-18"],
    ["Ribbon", F, "Icons rendered as black squares",
     "Figma SVGs wrap base64 bitmaps in a pattern fill JUCE cannot render; bitmaps "
     "extracted and preferred as PNG", "2026-09-18"],
    ["Legend", F, "Rel. SPL bar overlapped the plot",
     "Anchored to the gutter's left edge instead of right-anchored", "2026-09-18"],
    ["Plot", F, "Contour bands collapsed below -18 dB",
     "splBand quantizes the gradient instead of indexing a 7-entry palette that ran out "
     "at the UI's 3 dB step", "2026-09-18"],
    ["Packaging", F, "Assets embedded in the EXE",
     "Logos, ribbon icons and bundled fonts baked in by Tools/embed_assets.py. They "
     "were read from an Assets/ folder found by walking up from the CWD or EXE, so a "
     "recipient of just the .exe saw no logo, no glyphs and fallback fonts", "2026-09-18"],
    ["Packaging", C, "Version -> v1.4.0",
     "App, resource, installer, archive HTML/json, Windows Release EXE", "2026-09-18"],
]
write_table(ws140, 4,
            ["Area", "Type", "Item", "Detail", "When"],
            v140, [14, 10, 28, 72, 12],
            type_colors={A: SUCCESS, C: ACCENT, F: WARNING}, type_col=2)
ws140.freeze_panes = "A5"

# ===========================================================================
# Sheet 3: v1.3.8 detailed changes
# ===========================================================================
ws138 = wb.create_sheet("v1.3.8 Changes")
ws138.sheet_view.showGridLines = False
banner(ws138, "v1.3.8  -  Detailed Changes",
       "2026-09-04  |  Command line aliases + typed points + MOVE/ZOOM", 5)

A, C, F = "Added", "Changed", "Fixed"
v138 = [
    ["Terminal", A, "Command registry",
     "Short form and full name share one handler (L/LINE, PE/PENCIL, SPK/ADDSPEAKER, …)", "2026-09-04"],
    ["Terminal", A, "Typed-point DRAW",
     "After LINE/CIRCLE/… enter x,y (metres) or click the plot", "2026-09-04"],
    ["Terminal", A, "MOVE / ZOOM sessions",
     "MOVE base/second point; ZOOM [Extents/In/Out]", "2026-09-04"],
    ["Terminal", A, "Dock / Undock",
     "Floating terminal window; state remembered", "2026-09-04"],
    ["Terminal", A, "HELP / ?",
     "Atomik-branded command list (no third-party CAD branding)", "2026-09-04"],
    ["Terminal", F, "Undocked Esc / finish",
     "Completing or cancelling a command no longer loses the floating terminal", "2026-09-04"],
    ["Packaging", C, "Version → v1.3.8",
     "App, resource, archive HTML/json, Windows Release EXE", "2026-09-04"],
]
write_table(ws138, 4,
            ["Area", "Type", "Item", "Detail", "When"],
            v138, [14, 10, 28, 72, 12],
            type_colors={A: SUCCESS, C: ACCENT, F: WARNING}, type_col=2)
ws138.freeze_panes = "A5"

# ===========================================================================
# Sheet 3: v1.3.7 detailed changes
# ===========================================================================
ws137 = wb.create_sheet("v1.3.7 Changes")
ws137.sheet_view.showGridLines = False
banner(ws137, "v1.3.7  -  Detailed Changes",
       "2026-09-02  |  Gain fix + text box + clean slate + drawing UX", 5)

A, C, F = "Added", "Changed", "Fixed"
v137 = [
    ["Speakers", F, "Gain (dB) affects SPL",
     "Unity-gain reference normalisation; per-speaker level and array balance visible on heatmap", "2026-09-02"],
    ["Speakers", F, "Delete all selected",
     "Sidebar Delete removes every speaker in plot multi-selection, not just primary unit", "2026-09-02"],
    ["Plot tools", F, "Line first stroke",
     "Minimum drag distance prevents accidental micro-line consuming first click", "2026-09-02"],
    ["Plot tools", F, "Esc + Shape menu",
     "Esc returns to Select from drawing tools; cursor tool no longer opens Shape menu", "2026-09-02"],
    ["UI", A, "Command terminal",
     "Bottom-panel terminal replaces Phase/Arrival/STI placeholders; cls/clear supported", "2026-09-02"],
    ["Plot tools", A, "Text box annotations",
     "Shape menu Text Box; fill colour like shapes; rotation handle; double-click edit", "2026-09-02"],
    ["Speakers", C, "Delay slider max 10 ms",
     "Was 50 ms; presets unchanged", "2026-09-02"],
    ["Project", C, "Clean slate on first open",
     "No default speakers until user adds a Q21S unit", "2026-09-02"],
    ["Plot", C, "Range off by default",
     "Distance rings hidden until Range toggle is on", "2026-09-02"],
    ["Packaging", C, "Version → v1.3.7 (refresh)",
     "App, resource, installer defines, archive HTML/json, Windows Release EXE", "2026-09-02"],
]
write_table(ws137, 4,
            ["Area", "Type", "Item", "Detail", "When"],
            v137, [14, 10, 28, 72, 12],
            type_colors={A: SUCCESS, C: ACCENT, F: WARNING}, type_col=2)
ws137.freeze_panes = "A5"

# ===========================================================================
# Sheet 4: v1.3.6 detailed changes
# ===========================================================================
ws136 = wb.create_sheet("v1.3.6 Changes")
ws136.sheet_view.showGridLines = False
banner(ws136, "v1.3.6  -  Detailed Changes",
       "2026-08-31  |  Mic ring snap + shape-edge Snap tak", 5)

A, C, F = "Added", "Changed", "Fixed"
v136 = [
    ["Mic tool", F, "Original Drag::Mic ring snap",
     "Cursor-follow + 1/2/4/8 m latch + tak; no sticky lock from SelectionMove/object snap", "2026-08-31"],
    ["Plot Snap", F, "Tak when shapes meet",
     "Sound on rising edge of annotation edge contact; not speakers/mics/centres", "2026-08-31"],
    ["Docs", A, "start.md",
     "Repo-root build/run instructions for Windows Debug/Release and MSBuild", "2026-08-31"],
    ["Packaging", C, "Version → v1.3.6",
     "App, resource, installer defines, archive HTML/json", "2026-08-31"],
]
write_table(ws136, 4,
            ["Area", "Type", "Item", "Detail", "When"],
            v136, [14, 10, 28, 72, 12],
            type_colors={A: SUCCESS, C: ACCENT, F: WARNING}, type_col=2)
ws136.freeze_panes = "A5"

# ===========================================================================
# Sheet 3: v1.3.5 detailed changes
# ===========================================================================
ws135 = wb.create_sheet("v1.3.5 Changes")
ws135.sheet_view.showGridLines = False
banner(ws135, "v1.3.5  -  Detailed Changes",
       "2026-08-26  |  Mic tool + embedded Q21S Windows Setup", 5)

A, C, F = "Added", "Changed", "Fixed"
v135 = [
    ["Mic tool", A, "Virtual receivers on heatmap",
     "Add Mic / Place on ring; ring snap 1/2/4/8 m; live relative dB; Esc cancels arm", "2026-08-26"],
    ["Mic tool", A, "Show Degrees toggle",
     "Angle vs Q21S facing (0° = front, CCW) shown before dB on mic labels", "2026-08-26"],
    ["Mic tool", A, "Floating Frequency Response window",
     "Opens when mics exist; does not shrink the plot; curves from sampleIntensityAt", "2026-08-26"],
    ["Mic tool", A, "Tak snap sound",
     "In-memory WAV via winmm; no .wav asset on disk", "2026-08-26"],
    ["Packaging", A, "Embedded Q21S CSVs in EXE",
     "EmbeddedQ21SData; heatmaps work without MeasurementIntegrationPack or Excel", "2026-08-26"],
    ["Packaging", A, "Windows Setup v1.3.5",
     "AtomikSimulationEngine-Setup-v1.3.5.exe — EXE + fonts only (no Excel)", "2026-08-26"],
    ["Packaging", C, "Installer drops Excel folders",
     "setup.iss no longer ships Factory Readings / shyamGuildMeasurements xlsx", "2026-08-26"],
]
write_table(ws135, 4,
            ["Area", "Type", "Item", "Detail", "When"],
            v135, [14, 10, 28, 72, 12],
            type_colors={A: SUCCESS, C: ACCENT, F: WARNING}, type_col=2)
ws135.freeze_panes = "A5"

# ===========================================================================
# Sheet 3: v1.3.0 detailed changes
# ===========================================================================
ws13 = wb.create_sheet("v1.3.0 Changes")
ws13.sheet_view.showGridLines = False
banner(ws13, "v1.3.0  -  Detailed Changes",
       "Development window 2026-08-12 -> 2026-08-21 (portable ZIP same day)", 5)

A, C, F = "Added", "Changed", "Fixed"
v13 = [
    ["Engine", A, "Q21S BEM polar × 1/r SPL",
     "Far-field (~2 m) D(θ) coherent complex sum; r_spread floored at cabinet half-depth; absolute dB SPL from on-axis BEM; no ±5 m field stamp", "2026-08-21"],
    ["Array presets", A, "MATLAB-style cardioid",
     "Rear 180°, polarity −1, −6 dB, 3.5 ms, ~0.01 m spacing; coherent engine sum", "2026-08-21"],
    ["Docs / pack", A, "Single-sub heatmap pack",
     "docs/SINGLE_SUB_HEATMAP.md, native-Hz figures, generator script, dist_packages zip", "2026-08-21"],
    ["Archive", A, "Version archive (HTML + MongoDB)",
     "version-archive/: releases from v1.3.0; source zip / macOS DMG / Windows ZIP (EXE+Data); local artifacts serve without Mongo", "2026-08-21"],
    ["Packaging", A, "Windows portable ZIP",
     "EXE + MeasurementIntegrationPack\\Data (Q21S CSVs); required for other PCs — bare EXE alone cannot load heatmaps", "2026-08-21"],
    ["Plot tools", A, "Heatmap drawing tools",
     "Select, Pan, Pencil, Eraser, Ruler, Line + colour swatch; annotations in world metres", "2026-08-19"],
    ["Plot tools", A, "Shapes + fill opacity",
     "Rectangle, Square, Circle tools with opacity slider; undo/redo covers shapes", "2026-08-21"],
    ["Plot tools", A, "BEM / directivity field math",
     "Tightened BEM and measured-directivity field formation (commit 633fc36)", "2026-08-19"],
    ["Editing", A, "Undo / redo",
     "Ctrl+Z, Ctrl+Y, Ctrl+Shift+Z; letter is lowercased so Caps Lock still works; drawings, cabinets, layouts, control-panel edits", "2026-08-19"],
    ["Packaging", A, "Windows Release exe",
     "Builds\\Release\\Atomik Simulation Engine.exe; installer/README at v1.3.0", "2026-08-19"],
    ["DSP / UI (PS batch)", A, "IEC 1/3-octave frequencies",
     "20, 25, 31, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400, 500 Hz", "2026-08-12"],
    ["Cabinet", C, "Q21S footprint 750×784×917 mm",
     "Plan drawing + hit-test use true W×D; 1/r singularity floor = depth/2", "2026-08-21"],
    ["Engine", C, "Heatmap uses 2 m BEM arc",
     "Array/SPL prediction keeps far-field arc; Measured Polar can still show nearer distances", "2026-08-21"],
    ["Engine", C, "World 100×100 m",
     "Was 30×30 m in v1.0; full-grid Q21S coverage prediction", "2026-08-21"],
    ["Measurement", C, "Q21S product set / native BEM Hz",
     "Catalogue 20,29,52,81,98,153,198,256,309,352,400,401 Hz; UI Ground Plane only", "2026-08-21"],
    ["Branding", C, "Product name",
     "Atomik Acoustic Simulation Engine -> Atomik Simulation Engine; UI/PDF/CSV/installer/file version = v1.3.0", "2026-08-19"],
    ["Branding", C, "ATOMIK-only wordmark",
     "AUDIO line removed; Atomik_Logo_Dark.png / Atomik_Logo_Light.png", "2026-08-19"],
    ["Header", C, "Statistics button",
     "Stats pill renamed Statistics; width sized to the full label", "2026-08-19"],
    ["Measurement", C, "Ground Plane only",
     "Measurement UI is Ground Plane (no Room set in live UI)", "2026-08-12"],
    ["DSP", C, "Legend / dB floor -6 dB steps",
     "Colourbar ticks and floor slider on -6 dB; dBfloor is display range only", "2026-08-12"],
    ["UI", C, "XN18-n labels + Set to Default",
     "Cabinet labels use hyphen; Reset renamed Set to Default", "2026-08-12"],
    ["Engine", F, "No ±5 m BEM stamp on live map",
     "Full 100×100 m map follows polar × inverse-square instead of a near-field island", "2026-08-21"],
    ["Windows", F, "Q21S pack path (vs legacy D:\\shayam gui)",
     "Prefer exe/repo MeasurementIntegrationPack with Q21S_52Hz_2p0m.csv marker; avoid Factory/ShyamGuild-only legacy pack", "2026-08-21"],
    ["Header", F, "Version no longer clips",
     "Was showing v1... instead of v1.3.0; layout uses real logo width", "2026-08-19"],
    ["UI", F, "Small-screen logo",
     "Header/dashboard wordmark -20%; Scale minFactor 0.78", "2026-08-12"],
]
type_colors = {A: SUCCESS, C: ACCENT, F: WARNING}
write_table(ws13, 4, ["Section", "Type", "Item", "Details", "Date"],
            v13, [22, 10, 34, 78, 13],
            type_colors=type_colors, type_col=2)
ws13.freeze_panes = "A5"
ws13.auto_filter.ref = f"A4:E{4 + len(v13)}"

# ===========================================================================
# Sheet: v1.2.x beta UI redesign
# ===========================================================================
ws12 = wb.create_sheet("v1.2.x Beta UI")
ws12.sheet_view.showGridLines = False
banner(ws12, "v1.2.x  -  Beta UI redesign (through betav1.2.3)",
       "~2026-07  |  Graph colors.pdf chrome between v1.1.0 and v1.3.0", 5)
v12 = [
    ["Brand", C, "Graph colors.pdf tokens",
     "Charcoal / white / ash / signal red + heatmap cool/hot stops in BrandTheme.h", "~2026-07"],
    ["Brand", C, "Signal Red accents",
     "Interactive accent #ED2227 for controls (later refined in 1.3.0 ATOMIK branding)", "~2026-07"],
    ["Heatmap", C, "Colour map + Rel. SPL chrome",
     "Cool/hot stops and legend chrome aligned to brand mockups", "~2026-07"],
    ["UI", C, "Light / dark chrome",
     "Sidebar density, speaker markers, plot chrome, header actions", "~2026-07"],
    ["Packaging", A, "betav1.2.3-style Release",
     "Signed Windows packaging of the redesign build (see Tools/make_ui_changelog_doc.py)", "~2026-07"],
]
write_table(ws12, 4, ["Section", "Type", "Item", "Details", "Date"],
            v12, [16, 10, 34, 78, 13],
            type_colors=type_colors, type_col=2)
ws12.freeze_panes = "A5"
ws12.auto_filter.ref = f"A4:E{4 + len(v12)}"

# ===========================================================================
# Sheet 3: v1.1.0 detailed changes
# ===========================================================================
ws2 = wb.create_sheet("v1.1.0 Changes")
ws2.sheet_view.showGridLines = False
banner(ws2, "v1.1.0  -  Detailed Changes",
       "Development window 2026-06-25 -> 2026-06-29", 5)

changes = [
    # Section, Type, Item, Details, Date
    ["Theming & Preferences", A, "Dark / Light themes",
     "Dynamic app-wide switching via theme-aware palette + AtomikLookAndFeel; every screen/graph/dialog/heatmap chrome adapts live", "2026-06-25"],
    ["Theming & Preferences", A, "Preferences / Settings tab",
     "Choose theme and unit system (SI / Imperial); displayed values convert, internal calcs stay SI", "2026-06-26"],
    ["Theming & Preferences", A, "Persistent preferences",
     "Theme, units, grid visibility, measurement set, recent projects stored via PropertiesFile; broadcast via ChangeBroadcaster", "2026-06-26"],

    ["Project Workflow", A, "Project Dashboard at launch",
     "Separate window: new / open / recent projects; then opens main simulation window", "2026-06-26"],
    ["Project Workflow", A, "Project metadata capture",
     "Name, Engineer, Owner, Address, City, Country, Email, Mobile, Date - used in exports/reports", "2026-06-26"],
    ["Project Workflow", A, "Single-file .atmk projects",
     "Self-contained JSON: metadata + scene (speakers) + simulation settings; save/open", "2026-06-26"],

    ["Heatmap Export", A, "Client-ready heatmap sheet",
     "Header (logo, software name, title), project details, heatmap data (frequency, scale, units, legend) - generation logic untouched", "2026-06-26"],

    ["PDF Report", A, "Multi-page PDF report",
     "Cover, Project Info, Input Parameters, Results, Graphs, Heatmaps (30/50/80/100 Hz), Summary - generated programmatically", "2026-06-26"],
    ["PDF Report", A, "Custom PDF 1.4 writer (PdfDocument)",
     "Vector text + embedded images, no external dependency", "2026-06-26"],
    ["PDF Report", A, "AcousticAnalysis module",
     "RT60 (Sabine), absorption, transmission loss (mass-law), frequency response sampled from engine", "2026-06-26"],
    ["PDF Report", A, "GraphRender",
     "Line/bar charts rendered to images for the report", "2026-06-26"],

    ["Workspace / Grid / Layout", A, "Improved grid",
     "Major/minor lines, zoom-adaptive spacing (niceStep), higher contrast; show/hide toggle (persisted)", "2026-06-26"],
    ["Workspace / Grid / Layout", A, "Layout reference import",
     "Floor plans as background references - images (PNG/JPG) and DXF drawings", "2026-06-26"],
    ["Workspace / Grid / Layout", A, "DXF parser (DxfImport)",
     "Dependency-free 2D parser: LINE, LWPOLYLINE, POLYLINE/VERTEX, CIRCLE, ARC", "2026-06-26"],
    ["Workspace / Grid / Layout", A, "Layout alignment & visibility tools",
     "Move, rotate, scale (width in m), opacity, show/hide, lock, snap-to-grid; live drag", "2026-06-26"],

    ["Array Presets", A, "Cardioid presets (2/3/4 sub)",
     "Ready-to-use cardioid subwoofer arrays", "2026-06-26"],
    ["Array Presets", A, "End-fired presets (2/3/4 sub)",
     "Auto-calculated spacing, delay, polarity, orientation; manually editable after placement", "2026-06-26"],

    ["Measurement Datasets", A, "Two selectable sets (kept separate)",
     "Ground Plane = factory open-field (30/60/100/150/200 Hz, 1 m); Room = GYLT (30/80/200/500 Hz, 0.5/1 m)", "2026-06-29"],
    ["Measurement Datasets", A, "Per-set heatmaps & polar plots",
     "Switching reloads only that dataset + rebuilds directivity; each polar normalised to its own on-axis level; selection persisted", "2026-06-29"],
    ["Measurement Datasets", A, "Dynamic availability/legend",
     "Measured-polar 'available frequencies' and legend generated from the loaded dataset", "2026-06-29"],

    ["Responsive UI", A, "Minimum window size",
     "Main 1120x686, dashboard 680x537 - layout can never collapse/hide controls", "2026-06-27"],
    ["Responsive UI", A, "Fixed widescreen aspect ratio",
     "1340:820 preserved during resize - no stretching distortion", "2026-06-27"],
    ["Responsive UI", A, "Defensive layout clamps",
     "Workspace visible (P1), side panels usable (P2), controls keep usable size (P3)", "2026-06-27"],
    ["Responsive UI", A, "Scrollable control panel",
     "Dense controls scroll (viewport) instead of shrinking", "2026-06-27"],
    ["Responsive UI", A, "Responsive header + 'more options' menu",
     "Title auto-shrinks/never clips; Export PDF / Save / Preferences fold into kebab menu at all sizes", "2026-06-26"],

    ["Branding & Installer", A, "Atomik app icon embedded",
     "Windows .rc icon for exe, installer wizard, Add/Remove Programs, shortcuts; generated by make_icon.py", "2026-06-26"],
    ["Branding & Installer", A, "Windows installer (Inno Setup)",
     "Single Setup.exe: app + both datasets + fonts + icon; static CRT (no VC++ redist); per-user; uninstaller", "2026-06-26"],

    ["Versioning", C, "1.0.0 -> 1.1.0",
     "App title shows v1.1; installer 1.1", "2026-06-26"],
    ["Color system", C, "Removed all red; cyan accent system",
     "Header red->near-white; accents red->grey->cyan; hierarchy headings #F5F7FA / labels #B8C0CC / muted #7E8794; bg #0D0D12 / panel #17171D; accent #44D9E6; success #53D769; warning #FF6B6B; PDF FR line red->steel-blue", "2026-06-26"],
    ["Measured directivity", C, "Data-driven normalisation",
     "Each curve normalised to its own on-axis level instead of hard-coded reference SPLs", "2026-06-29"],
    ["Measurement Datasets", C, "Option renames",
     "Open Field -> Ground Plane; GYLT -> Room (datasets unchanged)", "2026-06-29"],

    ["Header", F, "Buttons no longer overlap title",
     "Fixed overlap in narrow/short windows", "2026-06-26"],
    ["Header", F, "Title no longer clips",
     "Was showing 'v1.' instead of 'v1.1'", "2026-06-26"],
    ["Recent Projects", F, "Recent Projects hygiene",
     "Entries whose .atmk no longer exists are hidden and pruned automatically", "2026-06-27"],
    ["Installer", F, "Fresh install guarantee",
     "Per-user settings folder cleared on install + uninstall; no stale recent projects/settings on reinstall", "2026-06-27"],
]

type_colors = {A: SUCCESS, C: ACCENT, F: WARNING}
write_table(ws2, 4, ["Section", "Type", "Item", "Details", "Date"],
            changes, [24, 10, 34, 70, 13],
            type_colors=type_colors, type_col=2)
ws2.freeze_panes = "A5"
ws2.auto_filter.ref = f"A4:E{4 + len(changes)}"

# ===========================================================================
# Sheet 3: v1.0.0 baseline
# ===========================================================================
ws3 = wb.create_sheet("v1.0.0 Baseline")
ws3.sheet_view.showGridLines = False
banner(ws3, "v1.0.0  -  Initial Baseline",
       "2026-06-22  (measured directivity added 2026-06-24)", 3)

base = [
    ["View modes", "SPL Heatmap, Pressure Map, Interference, Directivity, Measured Polar, Fit View", ""],
    ["Acoustic metrics", "SPL, Frequency Response, RT60, Absorption, Transmission Loss, heatmaps", ""],
    ["Frequency selector", "20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 150, 200, 500 Hz", ""],
    ["Measured directivity", "Horizontal directivity from .xlsx; applied when sim frequency matches; 1/3-octave smoothing; optional 3 dB contour bands", "2026-06-24"],
    ["Speaker / scene controls", "Per-unit X/Y, gain (dB), delay (ms), invert polarity, reverse orientation, enable/disable; add/delete; quick layouts (1/2/3 devices)", ""],
    ["Simulation settings", "Grid resolution, dB floor", ""],
    ["Exports", "PNG image, CSV data, SVG figure", ""],
    ["Engine", "Monopole summation + frequency-dependent piston directivity fallback; fractional-octave band power averaging", ""],
    ["Branding & UI", "JUCE desktop app; Montserrat + Space Mono fonts; Atomik identity", ""],
]
write_table(ws3, 4, ["Area", "Description", "Date"], base, [24, 90, 13])
ws3.freeze_panes = "A5"

# ===========================================================================
# Sheet 4: Timeline
# ===========================================================================
ws4 = wb.create_sheet("Timeline")
ws4.sheet_view.showGridLines = False
banner(ws4, "Development Timeline",
       "What landed when (derived from source history)", 2)

timeline = [
    ["2026-06-22", "v1.0 baseline: engine + UI (Main, MainComponent, ControlPanel, InfoPanel, RadiationPatternComponent, AcousticEngine, ColourMaps)"],
    ["2026-06-24", "Measured-directivity loading added (MeasurementData)"],
    ["2026-06-25", "v1.1 theming foundation: theme-aware palette + AtomikLookAndFeel (BrandTheme)"],
    ["2026-06-26", "Preferences/settings, .atmk projects + dashboard, enhanced heatmap export, PDF pipeline, grid + CAD/DXF, array presets, app icon + installer, header responsiveness, version bump, red->cyan overhaul"],
    ["2026-06-27", "Window scaling (min size, fixed aspect ratio, clamps); fresh-install guarantee; Recent Projects hygiene"],
    ["2026-06-29", "Dual measurement datasets (Ground Plane / Room), selectable + separate; final naming"],
    ["2026-08-12", "PS-001…PS-019: 1/3-octave freqs, Ground Plane-only UI, XN18-n, -6 dB legend, PDF/CSV/PNG polish, Set to Default"],
    ["2026-08-13", "prediction-software repo initial commit (Q21S / XN18 tree)"],
    ["2026-08-19", "Plot drawing tools + BEM/directivity math (633fc36)"],
    ["2026-07 (approx)", "v1.2.x beta UI redesign (Graph colors.pdf → betav1.2.3 packaging)"],
    ["2026-08-19", "v1.3.0 Windows build: Atomik Simulation Engine rename, ATOMIK-only logo, header v1.3.0 fix, Ctrl+Z/Y, Statistics button, single Release exe"],
    ["2026-08-21", "Q21S BEM polar×1/r, cardioid, cabinet size, heatmap docs, version archive; plot shapes + opacity"],
    ["2026-08-21", "Windows Q21S data-path fix + portable ZIP (EXE+MeasurementIntegrationPack); archive Windows = ZIP"],
]
write_table(ws4, 4, ["Date", "Work landed"], timeline, [14, 110])
ws4.freeze_panes = "A5"

# paint remaining backgrounds for a clean dark look
for sheet in (ws, ws13, ws2, ws3, ws4):
    paint_bg(sheet, sheet.max_row + 2, sheet.max_column)

out = os.path.join(os.path.dirname(__file__), "..", "CHANGELOG.xlsx")
out = os.path.abspath(out)
wb.save(out)
print("Wrote", out)
