﻿Atomik Simulation Engine v1.3.0.1 (Windows portable)

KEEP THIS FOLDER TOGETHER. The .exe alone cannot draw Q21S SPL heatmaps —
it needs MeasurementIntegrationPack\Data (Q21S_*.csv) beside it.

1. Unzip the whole folder
2. Run: Atomik Simulation Enginev1.3.0.1.exe
3. 1 device, 52 Hz, RUN — expect ~104.36 dB at 2 m on-axis
