#pragma once
#include <JuceHeader.h>
#include "BrandTheme.h"
#include "AppSettings.h"
#include "AcousticEngine.h"
#include "Speaker3DView.h"

// ---------------------------------------------------------------------------
// Read-only speaker Properties panel (name, cabinet size, position, DSP).
// ---------------------------------------------------------------------------
class SpeakerPropertiesDialog : public juce::Component
{
public:
    /** @param ordinal 1-based position among units of the SAME model
               (see speakerModelOrdinal), not the global index. */
    SpeakerPropertiesDialog (const Speaker& spk, int ordinal)
    {
        title_.setText ("Speaker Properties", juce::dontSendNotification);
        title_.setFont (Brand::techSemi (Brand::UI::scaledFont (15.0f)));
        title_.setColour (juce::Label::textColourId, Brand::heading());
        addAndMakeVisible (title_);

        const juce::String modelName = speakerModelName (spk.model);
        const juce::String name = juce::String (speakerModelTag (spk.model))
                                + "-" + juce::String (ordinal);
        const juce::String u = Units::lengthUnit();

        addRow ("Name", name);
        addRow ("Product", "Atomik " + modelName);
        // Each model carries its own enclosure now, so these are the selected
        // unit's real dimensions rather than Q21S's shown under every name.
        const auto cab = cabinetFor (spk.model);
        addRow ("Dimensions (W x H x D)",
               Units::dim (cab.widthM * 1000.0) + " x "
               + Units::dim (cab.heightM * 1000.0) + " x "
               + Units::dim (cab.depthM * 1000.0));
        addRow ("Plan footprint (W x D)",
               Units::dim (cab.widthM * 1000.0) + " x "
               + Units::dim (cab.depthM * 1000.0));
        addRow ("Position",
               "(" + juce::String (Units::metresToDisplay (spk.x), 2) + ", "
               + juce::String (Units::metresToDisplay (spk.y), 2) + ") " + u);
        addRow ("Gain", juce::String (spk.gainDB, 0) + " dB");
        addRow ("Delay", juce::String (spk.delayMs, 1) + " ms");
        addRow ("Polarity", spk.polarityInverted ? "Reverse" : "Normal");
        addRow ("Orientation", spk.reverseOrientation ? "Reverse (-x)" : "Forward (+x)");
        addRow ("Enabled", spk.enabled ? "Yes" : "No");

        // The rows give the numbers; this gives the shape. A plan view can
        // never show height, so the solid is the only place all three
        // dimensions are visible at once.
        view3dBtn_.setButtonText ("View in 3D");
        view3dBtn_.setColour (juce::TextButton::buttonColourId, Brand::accent());
        view3dBtn_.setColour (juce::TextButton::textColourOffId, Brand::onAccent());
        view3dBtn_.onClick = [this, m = spk.model, name = juce::String (speakerModelName (spk.model))]
        {
            auto* body = new Speaker3DView (m);
            juce::DialogWindow::LaunchOptions o;
            o.content.setOwned (body);
            o.dialogTitle = name + " - 3D view";
            o.dialogBackgroundColour = Brand::panel();
            o.escapeKeyTriggersCloseButton = true;
            o.useNativeTitleBar = true;
            // Not resizable: with it on, the window came up filling the screen
            // instead of sizing to the view, and a box drawn a metre across
            // tells you nothing more than one drawn at a sensible size.
            o.resizable = false;
            o.launchAsync();
        };
        addAndMakeVisible (view3dBtn_);

        setSize (360, 44 + (int) rows_.size() * 26 + 16 + 40);
    }

    void paint (juce::Graphics& g) override
    {
        g.fillAll (Brand::panel());
        g.setColour (Brand::border().withAlpha (0.55f));
        g.drawRect (getLocalBounds(), 1);
    }

    void resized() override
    {
        auto r = getLocalBounds().reduced (14, 12);
        title_.setBounds (r.removeFromTop (22));
        r.removeFromTop (8);
        for (auto* row : rows_)
        {
            auto line = r.removeFromTop (24);
            row->key.setBounds (line.removeFromLeft (line.getWidth() / 2));
            row->val.setBounds (line);
            r.removeFromTop (2);
        }
        r.removeFromTop (6);
        view3dBtn_.setBounds (r.removeFromTop (28));
    }

private:
    struct Row
    {
        juce::Label key, val;
    };

    void addRow (const juce::String& key, const juce::String& val)
    {
        auto* row = rows_.add (new Row());
        row->key.setText (key, juce::dontSendNotification);
        row->key.setFont (Brand::tech (Brand::UI::scaledFont (12.0f)));
        row->key.setColour (juce::Label::textColourId, Brand::muted());
        row->key.setJustificationType (juce::Justification::centredLeft);
        addAndMakeVisible (row->key);

        row->val.setText (val, juce::dontSendNotification);
        row->val.setFont (Brand::mono (Brand::UI::scaledFont (12.0f), true));
        row->val.setColour (juce::Label::textColourId, Brand::text());
        row->val.setJustificationType (juce::Justification::centredRight);
        addAndMakeVisible (row->val);
    }

    juce::Label title_;
    juce::TextButton view3dBtn_;
    juce::OwnedArray<Row> rows_;
};
